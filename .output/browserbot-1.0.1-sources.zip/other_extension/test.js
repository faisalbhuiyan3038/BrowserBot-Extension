
// Set up the game state
const gameOver = false;
let score = 0;
let snakePositions = [{ x: 15, y: 15 }];

// Update the game state on each tick
function updateGame() {
  // Check for game over condition and update the state accordingly
  if (!gameOver) {
    checkForGameOver();

    // Check for fruit collision and update the score accordingly
    const fruitPosition = { x: Math.floor(Math.random() * 50), y: Math.floor(Math.random() * 50) };
    if (snakePositions[0].x === fruitPosition.x && snakePositions[0].y === fruitPosition.y)) {
      score++;
    }
  }
}

// Update the game state based on user input
function handleKeyDown(event) {
  switch (event.keyCode) {
    case 37: // left arrow
      if (snakePositions[0].x > 15) {
        snakePositions.push({ x: snakePositions[snakePositions.length - 1].x - 1, y: snakePositions[snakePositions.length - 1].y });
      }
      break;
    case 38: // up arrow
      if (snakePositions[0].y > 15) {
        snakePositions.push({ x: snakePositions[snakePositions.length - 1].x, y: snakePositions[snakePositions.length - 1].y - 1 });
      }
      break;
    case 39: // right arrow
      if (snakePositions[0].x < 45) {
        snakePositions.push({ x: snakePositions[snakePositions.length - 1].x + 1, y: snakePositions[snakePositions.length - 1].y });
      }
      break;
    case 40: // down arrow
      if (snakePositions[0].y < 45) {
        snakePositions.push({ x: snakePositions[snakePositions.length - 1].x, y: snakePositions[snakePositions.length - 1].y + 1 });
      }
      break;
    default:
  }
}

// Check for game over condition and update the state accordingly
function checkForGameOver() {
  if (snakePositions[0].x < 0 || snakePositions[0].y < 0 || snakePositions[0].x > 45 || snakePositions[0].y > 45) {
    gameOver = true;
  } else if (snakePositions.some((position, index) => position.x === snakePositions[index - 1].x && position.y === snakePositions[index - 1].y))) {
    gameOver = true;
  }
}

// Update the game state on each tick
setInterval(() => {
  updateGame();
}, 100);

// Render the game board and the snake
const gameBoard = document.getElementById("game-board");
if (gameBoard) {
  const gameOverDiv = document.createElement("div");
  if (gameOver) {
    gameOverDiv.innerHTML = "Game Over!";
  } else {
    gameOverDiv.innerHTML = `Score: ${score}`;
  }
  gameBoard.appendChild(gameOverDiv);

  // Render the snake
  const snakeElement = document.createElement("div");
  snakeElement.classList.add("snake");
  for (const position of snakePositions) {
    const snakeSegment = document.createElement("div");
    snakeSegment.style.left = position.x * 10 + 'px';
    snakeSegment.style.top = position.y * 10 + 'px';
    snakeElement.appendChild(snakeSegment);
  }
  gameBoard.appendChild(snakeElement);

  // Render the fruit
  const fruitElement = document.createElement("div");
  fruitElement.classList.add("fruit");
  const fruitPosition = { x: Math.floor(Math.random() * 50), y: Math.floor(Math.random() * 50) };
  fruitElement.style.left = fruitPosition.x * 10 + 'px';
  fruitElement.style.top = fruitPosition.y * 10 + 'px';
  gameBoard.appendChild(fruitElement);
}